#/bin/bash
#echoes arguments
echo $*
