echo "rsync --archive ~tkt-cam/public_html/`date +%Y/%m/%d` exactum/`date +%A.%Y.%m.%d`"
