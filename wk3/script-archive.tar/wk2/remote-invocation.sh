#!/bin/bash
#executes command (arg 2) at host (arg 1)
ssh $1 $2
