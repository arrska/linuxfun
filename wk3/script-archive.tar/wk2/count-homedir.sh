#!/bin/bash
#count the number of files in home directory ~ 

ls -R ~ | wc -l
